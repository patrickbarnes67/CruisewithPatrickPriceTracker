require("dotenv").config();
const express = require("express");
const path = require("path");
const cron = require("node-cron");
const nodemailer = require("nodemailer");
const Database = require("better-sqlite3");
const { getFare } = require("./priceProvider");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));
app.use((req, res, next) => {
  const allowed = process.env.ALLOWED_ORIGIN || "http://localhost:3000";
  res.setHeader("Access-Control-Allow-Origin", allowed);
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,DELETE,OPTIONS");
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});

const db = new Database(process.env.DATABASE_PATH || "./data.sqlite");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS trackers (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 email TEXT NOT NULL,
 ship TEXT NOT NULL,
 departure_date TEXT NOT NULL,
 cabin_type TEXT NOT NULL,
 occupancy INTEGER NOT NULL,
 currency TEXT NOT NULL DEFAULT 'GBP',
 baseline_price REAL,
 last_price REAL,
 last_fare_basis TEXT,
 last_checked_at TEXT,
 active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS price_history (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 tracker_id INTEGER NOT NULL,
 amount REAL NOT NULL,
 currency TEXT NOT NULL,
 fare_basis TEXT,
 source_url TEXT,
 checked_at TEXT NOT NULL,
 FOREIGN KEY(tracker_id) REFERENCES trackers(id)
);
`);

function validEmail(value) {
  return typeof value === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
}
function sendTransport() {
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) return null;
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: String(process.env.SMTP_SECURE).toLowerCase() === "true",
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
}
async function emailChange(tracker, previous, current, checkedAt, sourceUrl) {
  const transport = sendTransport();
  if (!transport) {
    console.warn("SMTP is not configured; email not sent for tracker", tracker.id);
    return;
  }
  const diff = current.amount - previous;
  const movement = diff < 0 ? "dropped" : "increased";
  const fmt = n => new Intl.NumberFormat("en-GB", { style:"currency", currency:current.currency }).format(n);
  await transport.sendMail({
    from: process.env.EMAIL_FROM || process.env.SMTP_USER,
    to: tracker.email,
    subject: `Princess fare ${movement}: ${tracker.ship} (${tracker.departure_date})`,
    text: [
      `The tracked Princess Cruises fare has ${movement}.`,
      ``,
      `Ship: ${tracker.ship}`,
      `Departure: ${tracker.departure_date}`,
      `Cabin: ${tracker.cabin_type}`,
      `Occupancy: ${tracker.occupancy}`,
      `Previous price: ${fmt(previous)}`,
      `Current price: ${fmt(current.amount)}`,
      `Change: ${diff > 0 ? "+" : ""}${fmt(diff)}`,
      `Fare basis: ${current.fareBasis || "Not supplied"}`,
      `Checked: ${checkedAt}`,
      sourceUrl ? `Source: ${sourceUrl}` : "",
      ``,
      `This email was sent because you asked to be notified of price changes.`
    ].filter(Boolean).join("\n")
  });
}
async function checkOne(tracker) {
  let fare;
  try { fare = await getFare(tracker); }
  catch (e) { console.error("Fare check failed", tracker.id, e.message); return { id: tracker.id, status:"error" }; }
  if (!fare || !Number.isFinite(Number(fare.amount)) || Number(fare.amount) <= 0) {
    return { id: tracker.id, status:"no_verified_fare" };
  }
  if (fare.currency !== tracker.currency) {
    console.warn("Currency mismatch; skipping tracker", tracker.id);
    return { id: tracker.id, status:"currency_mismatch" };
  }
  const amount = Number(fare.amount);
  const checkedAt = fare.checkedAt || new Date().toISOString();
  db.prepare(`INSERT INTO price_history (tracker_id,amount,currency,fare_basis,source_url,checked_at)
              VALUES (?,?,?,?,?,?)`).run(tracker.id, amount, fare.currency, fare.fareBasis || null, fare.sourceUrl || null, checkedAt);
  const previous = tracker.last_price;
  db.prepare(`UPDATE trackers SET last_price=?, last_fare_basis=?, last_checked_at=? WHERE id=?`)
    .run(amount, fare.fareBasis || null, checkedAt, tracker.id);
  if (previous !== null && previous !== undefined && Number(previous) !== amount) {
    try { await emailChange(tracker, Number(previous), { amount, currency:fare.currency, fareBasis:fare.fareBasis }, checkedAt, fare.sourceUrl); }
    catch (e) { console.error("Email failed for tracker", tracker.id, e.message); }
  }
  return { id:tracker.id, status: previous == null ? "baseline_saved" : (Number(previous) === amount ? "unchanged" : "changed"), previous, current:amount };
}
async function runChecks() {
  const trackers = db.prepare("SELECT * FROM trackers WHERE active=1").all();
  const results = [];
  for (const tracker of trackers) results.push(await checkOne(tracker));
  return results;
}

app.get("/api/health", (_req,res) => res.json({ ok:true, providerConfigured:"Replace priceProvider.js to enable live checks" }));
app.post("/api/trackers", (req,res) => {
  const { email, ship, departureDate, cabinType, occupancy, currency = "GBP" } = req.body || {};
  if (!validEmail(email)) return res.status(400).json({ error:"Enter a valid email address." });
  if (!ship || !departureDate || !cabinType) return res.status(400).json({ error:"Ship, departure date and cabin type are required." });
  if (!Number.isInteger(Number(occupancy)) || Number(occupancy) < 1 || Number(occupancy) > 8) return res.status(400).json({ error:"Occupancy must be between 1 and 8." });
  if (!["GBP","USD","EUR","AUD","CAD"].includes(currency)) return res.status(400).json({ error:"Unsupported currency." });
  const info = db.prepare(`INSERT INTO trackers (email,ship,departure_date,cabin_type,occupancy,currency)
    VALUES (?,?,?,?,?,?)`).run(email.trim().toLowerCase(), ship.trim(), departureDate, cabinType, Number(occupancy), currency);
  res.status(201).json({ id:info.lastInsertRowid, message:"Tracker created. A verified baseline price will be saved when the fare provider is configured and a check succeeds." });
});
app.get("/api/trackers", (req,res) => {
  // For privacy, this endpoint only returns trackers matching an email query.
  const email = String(req.query.email || "").trim().toLowerCase();
  if (!validEmail(email)) return res.status(400).json({ error:"Provide an email query to view trackers." });
  const rows = db.prepare(`SELECT id,ship,departure_date,cabin_type,occupancy,currency,last_price,last_checked_at,active,created_at
    FROM trackers WHERE email=? ORDER BY created_at DESC`).all(email);
  res.json(rows);
});
app.delete("/api/trackers/:id", (req,res) => {
  const email = String(req.query.email || "").trim().toLowerCase();
  if (!validEmail(email)) return res.status(400).json({ error:"Email is required to remove a tracker." });
  const result = db.prepare("DELETE FROM trackers WHERE id=? AND email=?").run(Number(req.params.id), email);
  if (!result.changes) return res.status(404).json({ error:"Tracker not found." });
  db.prepare("DELETE FROM price_history WHERE tracker_id=?").run(Number(req.params.id));
  res.json({ ok:true });
});
// Protected operational endpoint: set ADMIN_TOKEN before exposing it.
app.post("/api/admin/check-now", async (req,res) => {
  if (!process.env.ADMIN_TOKEN || req.get("x-admin-token") !== process.env.ADMIN_TOKEN) return res.sendStatus(401);
  res.json(await runChecks());
});
const cronSpec = process.env.CHECK_CRON || "0 8 * * *";
cron.schedule(cronSpec, () => runChecks().catch(err => console.error(err)));

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Cruise with Patrick Princess Price Tracker running on http://localhost:${port}; daily checks: ${cronSpec}`));
