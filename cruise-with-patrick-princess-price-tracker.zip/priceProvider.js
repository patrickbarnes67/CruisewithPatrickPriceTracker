/**
 * Cruise with Patrick Princess Price Tracker — fare provider adapter.
Princess.com is the intended comparison source. Do not scrape or extract its
content automatically without authorization; the UK Princess.com terms prohibit
automated scraping/extraction unless legally permitted. Connect an authorized API/feed.
 * Never fabricate a price or silently substitute a different fare.
 */
async function getFare(criteria) {
  // TODO: Implement using a licensed/authorized fare feed or provider API.
  // The provider must match ship, departure date, cabin category, occupancy,
  // currency and fare/package basis where available.
  console.warn("No fare provider configured; skipping check for tracker", criteria.id);
  return null;
}

module.exports = { getFare };
