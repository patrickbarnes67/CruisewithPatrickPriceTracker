(() => {
  // If embedding copied files onto a different domain, set this to the backend URL.
  const API_BASE = "";
  const form = document.getElementById("tracker-form");
  const status = document.getElementById("status");
  form.addEventListener("submit", async event => {
    event.preventDefault();
    const button = form.querySelector("button");
    button.disabled = true;
    status.textContent = "Creating your tracker…";
    const data = Object.fromEntries(new FormData(form).entries());
    delete data.consent;
    data.occupancy = Number(data.occupancy);
    try {
      const response = await fetch(`${API_BASE}/api/trackers`, {
        method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(data)
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Could not create tracker.");
      status.textContent = `Tracker #${result.id} created. ${result.message}`;
      form.reset();
    } catch (err) {
      status.textContent = `${err.message} Check that the tracker service is running.`;
    } finally {
      button.disabled = false;
    }
  });
})();
