# Cruise with Patrick Cruise with Patrick Princess Price Tracker

An embeddable website widget plus a small backend service branded **Cruise with Patrick Princess Price Tracker** for tracking Princess Cruises fares and emailing subscribers when a tracked fare changes.

## Princess.com data-source requirement
The app is designed to compare against Princess.com, but the official UK terms prohibit automated scraping/extraction of site data unless legally permitted. This project therefore does **not** scrape Princess.com or claim to have a live price connection. Connect a Princess-authorized API/feed or obtain written permission for an automated integration before enabling automated checks. The public Princess.com cruise-search page is linked in the form for manual verification.

## Important limitation
Princess Cruises does not provide a generally available public fare API for this app to use out of the box. The included `priceProvider` is deliberately an adapter/stub: connect it to a permitted, reliable fare data source before deploying. Do not assume a price is valid unless the provider returns a verified amount for the exact sailing, occupancy, cabin category, currency and fare basis. Avoid scraping if it violates site terms or access controls.

## Features
- Collects ship, departure date, cabin type, occupancy, currency and email address.
- Saves tracking requests in SQLite.
- Scheduled daily checks (configurable).
- Emails subscribers when the tracked fare changes, including previous and current price.
- A simple public JSON API and an embeddable form.
- Price-change emails include the tracking criteria and direction of change.

## Requirements
- Node.js 20+
- SMTP credentials (e.g. your email provider's SMTP service)
- A permitted Princess fare data source/provider implementation

## Run locally
1. Copy `.env.example` to `.env` and fill in SMTP settings.
2. Install dependencies: `npm install`
3. Start: `npm start`
4. Open `http://localhost:3000`

## Embed on a website
Host this service somewhere public (for example, your own server or a Node-compatible hosting service), then add this snippet to the page:

```html
<iframe
  src="https://YOUR-TRACKER-DOMAIN.example/embed.html"
  title="Princess cruise price tracker"
  style="width:100%;min-height:680px;border:0;border-radius:12px;"
  loading="lazy">
</iframe>
```

For a more integrated look, copy `public/embed.html` and `public/widget.css` into your site and set `API_BASE` in `public/widget.js` to your service URL. Configure CORS in `server.js` to allow only your website origin before going live.

## Configure a real fare provider
Edit `priceProvider.js`. Implement `getFare(criteria)` so it returns:

```js
{
  amount: 1234.56,          // numeric total price
  currency: "GBP",
  fareBasis: "matching fare name / package",
  checkedAt: new Date().toISOString(),
  sourceUrl: "https://..."
}
```

Return `null` or throw an error if a verified fare cannot be found. Do not return estimated or mismatched fares. Match the same ship, sailing date, occupancy, cabin category, currency, and fare/package basis where possible.

## Deployment checklist
- Set a strong `SESSION_SECRET` even if you later add admin sessions.
- Use a managed persistent disk or external database in production; SQLite is fine for a small demo but depends on persistent storage.
- Restrict CORS to your own website origin.
- Add rate limiting, CAPTCHA/bot protection, unsubscribe links, and a privacy policy before public launch.
- Confirm consent to email notifications and comply with applicable privacy/email laws.
- Keep SMTP credentials and provider credentials server-side only.
- Add an admin-only endpoint or dashboard before letting users manage other users' trackers.
- The demo sends email when a new verified price differs from the last verified price. It does not send an email for a failed/empty check.


Official reference: https://www.princess.com/cruise-search/search/results
Terms: https://gb-www.princess.com/en-uk/legal/legal-information
